-- Make the datasets bucket public so users can upload files
UPDATE storage.buckets 
SET public = true 
WHERE name = 'datasets';

-- Drop existing policies if any
DROP POLICY IF EXISTS "Allow public uploads to datasets bucket" ON storage.objects;
DROP POLICY IF EXISTS "Allow public access to datasets" ON storage.objects;

-- Allow anyone to upload to the datasets bucket
CREATE POLICY "Allow public uploads to datasets bucket"
ON storage.objects
FOR INSERT
TO public
WITH CHECK (bucket_id = 'datasets');

-- Allow anyone to read from the datasets bucket
CREATE POLICY "Allow public access to datasets"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'datasets');